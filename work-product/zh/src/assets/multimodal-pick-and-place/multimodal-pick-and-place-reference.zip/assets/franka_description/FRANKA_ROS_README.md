# ROS integration for Franka Robotics research robots

[![CI](https://github.com/frankarobotics/franka_ros/actions/workflows/ci.yml/badge.svg)](https://github.com/frankarobotics/franka_ros/actions/workflows/ci.yml)


See the [Franka Control Interface (FCI) documentation][fci-docs] for more information.

## License

All packages of `franka_ros` are licensed under the [Apache 2.0 license][apache-2.0].

[apache-2.0]: https://www.apache.org/licenses/LICENSE-2.0.html
[fci-docs]: https://frankarobotics.github.io/docs
